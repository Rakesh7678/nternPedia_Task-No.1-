let currentNumber = "";
let previousNumber = "";
let operator = "";
let expression = ""; // This variable stores the displayed expression

function appendNumber(number) {
  currentNumber += number;
  expression += number;
  document.getElementById("display").value = expression;
}

function appendOperator(op) {
  previousNumber = currentNumber;
  currentNumber = "";
  operator = op;
  expression += op;
  document.getElementById("display").value = expression;
}

function calculate() {
  let result = 0;
  const prevNum = parseFloat(previousNumber);
  const currNum = parseFloat(currentNumber);

  if (operator === "+") {
    result = prevNum + currNum;
  } else if (operator === "-") {
    result = prevNum - currNum;
  } else if (operator === "*") {
    result = prevNum * currNum;
  } else if (operator === "/") {
    if (currNum === 0) {
      alert("Division by zero!");
      return;
    }
    result = prevNum / currNum;
  }

  currentNumber = result.toString();
  previousNumber = "";
  operator = "";
  expression = currentNumber; // Update expression to only show result
  document.getElementById("display").value = expression;
}

function clearDisplay() {
  currentNumber = "";
  previousNumber = "";
  operator = "";
  expression = "";
  document.getElementById("display").value = "";
}
